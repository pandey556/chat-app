package com.cometchat.pro.uikit.ui_components.shared.cometchatReaction.listener;

import com.cometchat.pro.uikit.ui_components.shared.cometchatReaction.model.Reaction;

public interface OnReactionClickListener {
    void onEmojiClicked(Reaction emojicon);
}
