package com.cometchat.pro.uikit.ui_components.messages.message_actions.listener;

import android.content.DialogInterface;

public interface MessageActionCloseListener
{
    public void handleDialogClose(DialogInterface dialog);
}
