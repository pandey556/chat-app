package com.cometchat.pro.uikit.ui_resources.utils.recycler_touch;

import android.view.View;

public abstract class ClickListener {
    public   void onClick(View var1, int var2){}

    public void onLongClick(View var1, int var2){}
}