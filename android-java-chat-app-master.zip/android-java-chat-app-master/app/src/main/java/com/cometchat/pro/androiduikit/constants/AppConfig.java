package com.cometchat.pro.androiduikit.constants;

public class AppConfig {

    public class AppDetails {

        public static final String APP_ID = "XXXXXXXXXXXXXXXX";

        public static final String AUTH_KEY = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

        public static final String REGION = "XX";
    }
}

